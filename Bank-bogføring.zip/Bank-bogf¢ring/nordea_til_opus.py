import openpyxl
import csv
import glob
import os
import datetime
from time import sleep

now = datetime.datetime.now()
day = str(int(now.strftime('%d')))
month = str(int(now.strftime('%m')))
year = now.strftime('%Y')
hour = now.strftime('%H')
minute = now.strftime('%M')





# Change accounting info here
trash_account = '95990009'
bank_account = '90540000'
# Change accounting info here





bank_parameters = {0: [17, 19, 21], 1: [53, 54], 2: [43, 44, 45, 46], 3: [13]}      # reference, advistliste, afsender og posteringstype - vaerdierne svarer til positionerne i posteringerne fra Nordea, noeglerne svarer til positionerne i regel-arket. 
erp_file_headers = ['Artskonto', 'Omkostningssted', 'PSP-element', 'Profitcenter', 'Ordre', 'Debet/kredit', 'Beløb', 'Næste agent', 'Tekst', 'Betalingsart', 'Påligningsår', 'Betalingsmodtagernr.', 'Betalingsmodtagernr.kode', 'Ydelsesmodtagernr.', 'Ydelsesmodtagernr.kode', 'Ydelsesperiode fra', 'Ydelsesperiode til', 'Oplysningspligtnr.', 'Oplysningspligtmodtagernr.kode', 'Oplysningspligtkode', 'Netværk', 'Operation', 'Mængde', 'Mængdeenhed', 'Referencenøgle']

def match_parameter(posting, operator, search_value, parameter_index):
    try:
        if operator.lower() == 'starter med':
            return posting[parameter_index].lower().startswith(search_value)
        elif operator.lower() == 'slutter med':
            return posting[parameter_index].lower().endswith(search_value)
        elif operator.lower() == 'indeholder':
            return search_value in posting[parameter_index].lower()
    except IndexError:
        return False

def match_amount(posting_amount, operator, rule_amount1, rule_amount2):
    if operator.lower() == 'større end':
        return float(posting_amount) > float(rule_amount1.replace(',','.'))
    elif operator.lower() == 'mindre end':
        return float(posting_amount) < float(rule_amount1.replace(',','.'))
    elif operator.lower() == 'lig med':
        return float(posting_amount) == float(rule_amount1.replace(',','.'))
    elif operator.lower() == 'mellem':
        return float(posting_amount) > float(rule_amount1.replace(',','.')) and float(posting_amount) < float(rule_amount2.replace(',','.'))
    elif operator == '':
        return True
    
def calculate_specificity(rule):
    # Taeller antallet af udfyldte parametre
    return sum(1 for field in rule[:4] if field)

def text_generation(text_variation, standard_reference, standard_sender, standard_advis, secondary_advis): 
    text = text_variation.lower()

    if text == 'tekst fra bank':
        return standard_reference
    elif text == 'afsender fra bank':
        return standard_sender if standard_sender else standard_reference
    elif text == 'advis fra bank':
        return standard_advis if standard_advis else (secondary_advis if secondary_advis else standard_reference)
    else:
        return text_variation





# Change path to directory here
os.chdir(r'D:\Nordea\Posteringsbilag\Hovedkonto')
# Change path to directory here





rules_file = openpyxl.load_workbook('Regler.xlsx')
rules_file_tab1 = rules_file['Regler']

old_erp_files = glob.glob('Posteringsbilag Nordea*') 
for bilag in old_erp_files:
    os.replace(bilag, 'Indlaeste/'+bilag)

new_erp_files = glob.glob('*.nda')
print(f'Indlæser {len(new_erp_files)} filer.')

COL_START = 1
COL_END = 13
rules_list = [ # konverterer regler fra worksheet til list object
    [str(rules_file_tab1.cell(row=row_index, column=col_index).value) if str(rules_file_tab1.cell(row=row_index, column=col_index).value) != 'None' else '' for col_index in range(COL_START, COL_END)]
    for row_index in range(2, rules_file_tab1.max_row + 1)
]

# sorterer regler saa regler med flere parametre prioriteres
rules_list.sort(key=calculate_specificity, reverse=True)

sum_of_new_erp_files = 0
postings_with_no_match = 0

# sleep(2)

for file in new_erp_files: # for hver .nda-fil
    sum_of_new_erp_files += 1

    bankpostings_file = open(file)
    bankpostings_file_reader = csv.reader(bankpostings_file)
    bankpostings_list = list(bankpostings_file_reader)

    erp_file_name = f'Posteringsbilag Nordea {sum_of_new_erp_files} - semikolonsepareret (udlæst {day}-{month}-{year} {hour}.{minute}).csv'

    with open(erp_file_name, 'w', newline='') as erp_file:
        output_writer = csv.writer(erp_file, delimiter=';')
        output_writer.writerow(erp_file_headers)

        for posting in bankpostings_list:
            complete_matches = 0
            sum_of_rules_checked = 0
            match_all_parameters_bool = False

            posting_amount = posting[8]
            amount_sign = posting[9]
            clean_amount = posting[10].replace('.',',')
            standard_reference = posting[17]
            standard_sender = posting[43] if not posting[43] == '' else False 
            standard_advis = posting[53] if len(posting) > 53 else False
            secondary_advis = posting[54] if len(posting) > 54 else False
           
            bank_debet_credit = "Debet" if amount_sign == "+" else "Kredit"
            main_debet_credit = "Kredit" if bank_debet_credit == "Debet" else "Debet"

            for rule in rules_list: # for hver raekke i regel_raekke-arket
                sum_of_parameters_checked = 0
                matches = 0
                match_all_parameters_bool = False
                
                amount_operator = rule[7]
                parameter_operator = rule[4]
                text_variation = rule[8]

                artskonto = rule[9]
                exception = True if artskonto == bank_account else False
                psp = rule[10]
                sio = rule[11]
                rule_amount1 = rule[5]
                rule_amount2 = rule[6]

                if sum_of_rules_checked > 1 and complete_matches > 0:    # hvis der er skrevet en linje ud fra en raekke, spring alle andre over
                    pass
                else:
                    for rule_parameter in rule[:4]: # for hver mulig delregel
                        search_value = str(rule_parameter).lower()

                        if search_value != '' and not search_value.startswith('#'): # hvis soegeordet ikke er blankt eller starter med #, som indikerer en inaktiv regel
                            parameter_variations = bank_parameters[sum_of_parameters_checked] # afsender og advis kan fremgaa af flere parametre i udtraekket fra Nordea, derfor denne variable
                            match_found = False

                            for parameter_index in parameter_variations: # for hver mulig parameter pr. delregel (reference, advis, afsender, posteringstype)
                                if match_parameter(posting, parameter_operator, search_value, parameter_index):
                                    matches += 1
                                    break

                        sum_of_parameters_checked += 1
                    
                    if matches == calculate_specificity(rule):  # hvis der er lige saa mange matches som udfyldte parametre
                        match_all_parameters_bool = True

                    match_on_amount_bool = match_amount(posting_amount, amount_operator, rule_amount1, rule_amount2)
                                
                    if match_all_parameters_bool and match_on_amount_bool :                                
                        if not exception:
                            text = text_generation(text_variation, standard_reference, standard_sender, standard_advis, secondary_advis)
                        
                            posting_data_main = [artskonto, '', psp, '', sio, main_debet_credit, clean_amount, '', text, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
                            posting_data_bank = [bank_account, '', '', '', '', bank_debet_credit, clean_amount, '', text, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
                                            
                            output_writer.writerow(posting_data_main)
                            output_writer.writerow(posting_data_bank)
                            
                        complete_matches += 1

                sum_of_rules_checked += 1      

            if complete_matches == 0:
                postings_with_no_match += 1
                text = f'{standard_sender} - {standard_reference}' if standard_sender else standard_reference

                posting_data_main = [trash_account, '', '', '', '', main_debet_credit, clean_amount, '', text, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
                posting_data_bank = [bank_account, '', '', '', '', bank_debet_credit, clean_amount, '', text, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
                
                output_writer.writerow(posting_data_main)
                output_writer.writerow(posting_data_bank)

    bankpostings_file.close()
    os.replace(file, 'Indlaeste/'+file)

print('Færdig!')
print('')
print(f'{postings_with_no_match} posteringer kunne ikke matches og konteres på 95990009.')
sleep(5)

# SNITFLADE NORDEA v. 3
# 0 SWIFT-adresse
# 1 Reg.nr.
# 2 Kontonr.
# 3 Valutakode
# 4 Kundenavn
# 5 Udskriftsnummer
# 6 Bogfoeringsdato
# 7 Rentedato
# 8 Beloeb
# 9 Fortegn
# 10 Beloeb
# 11 SWIFT-tekstkode
# 12 Posteringstype kode
# 13 Posteringstype tekst
# 14 Reference
# 15 Reference antal
# 16 Reference kode 1
# 17 Reference tekst 1
# 18 Reference kode 2
# 19 Reference tekst 2
# 20 Reference kode 3
# 21 Reference tekst 3
# 22 Reference kode 4
# 23 Reference tekst 4
# 24 Reference kode 5
# 25 Reference tekst 5
# 26 Reference kode 6
# 27 Reference tekst 6
# 28 Antal advislinier
# 29 Advisposteringr 1
# 30 Advisposteringr 2
# 31 Advisposteringr 3
# 32 Advisposteringr 4
# 33 Advisposteringr 5
# 34 Advisposteringr 6
# 35 Saldo
# 36 Fortegn
# 37 Saldo
# 38 Reserveret til fremtidig brug
# 39 Reserveret til fremtidig brug
# 40 Kontonavn
# 41 IBAN
# 42 Tilbagefoersel
# 43 Indbetaler 1
# 44 Indbetaler 2
# 45 Indbetaler 3
# 46 Indbetaler 4
# 47 Indbetaler 5
# 48 Debitor identifikation
# 49 Ref. prim. dok.
# 50 Meddelelsesnr.
# 51 Arkivoplysning
# 52 Antal advislinier
# 53 Advislinie 1-41
# 54 
# 55 
# 56 
# 57 
# 58 
# 59 
# 60 